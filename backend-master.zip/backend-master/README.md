# backend
materijali sa pripremnih radionica za Hakaton za srednjoskolce: back-end
